const inputsValueObj = () => {
  const inputs = {
    first: "",
    middle: "",
    last: "",
    phone: "",
    email: "",
    url: "",
    alt: "",
    state: "",
    country: "",
    city: "",
    street: "",
    houseNumber: "",
    zip: "",
  };
  return inputs;
};
export { inputsValueObj };
