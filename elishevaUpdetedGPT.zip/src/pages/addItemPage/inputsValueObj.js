const inputsValueObj = () => {
  const inputs = {
    title: "",
    brand: "",
    phone: "",
    size: "",
    description: "",
    value: "",
    currency: "",
    url: "",
    alt: "",
    state: "",
    country: "",
    city: "",
    street: "",
    houseNumber: "",
    //zip: "",
  };
  return inputs;
};
export { inputsValueObj };
