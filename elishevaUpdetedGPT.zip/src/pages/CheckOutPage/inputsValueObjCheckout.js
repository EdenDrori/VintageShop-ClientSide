const inputsValueObjCheckout = () => {
  const inputs = {
    first: "",
    last: "",
    // phone: "",
    // email: "",
    state: "",
    country: "",
    city: "",
    street: "",
    houseNumber: "",
    zip: "",
  };
  return inputs;
};
export { inputsValueObjCheckout };
